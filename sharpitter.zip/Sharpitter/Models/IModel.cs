﻿using System;

namespace Sharpitter.Models {
	
	public interface IModel {

		bool Save();

		bool Delete();

	}

}

