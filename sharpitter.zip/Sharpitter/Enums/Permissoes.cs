﻿using System;

namespace Sharpitter.Enums {
	
	public enum Permissoes {
		Usuario,
		Administrador
	}

}